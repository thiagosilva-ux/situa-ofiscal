"""
server.py  –  Automação Fiscal ALLDAX
v7 — Seletor de responsável + persistência de dados + dashboard /stats
"""
from flask import Flask, request, send_file, jsonify
import io, traceback, os, json, re
from pathlib import Path
from datetime import datetime, date
from gerar_docx import parse_pdf, gerar

app = Flask(__name__, static_folder='static', static_url_path='')

TEMPLATE_DIR = str(Path(__file__).parent / 'template_base')
TMP_OUT      = '/tmp/informativo_fiscal.docx'
DB_PATH      = Path(__file__).parent / 'dados_levantamentos.json'

# ──────────────────────────────────────────────────
# BANCO DE DADOS LOCAL (JSON)
# ──────────────────────────────────────────────────
def load_db():
    if DB_PATH.exists():
        with open(DB_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {'levantamentos': []}

def save_db(db):
    with open(DB_PATH, 'w', encoding='utf-8') as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

def salvar_levantamento(dados, responsavel):
    """Salva/atualiza o levantamento no banco local."""
    db = load_db()
    cnpj = dados.get('cnpj', '').strip()
    cliente = dados.get('cliente', '').strip()
    total = float(dados.get('total', 0))
    data_rel = dados.get('data_analise', datetime.today().strftime('%d/%m/%Y'))

    # Remove entrada anterior do mesmo CNPJ para não duplicar
    db['levantamentos'] = [l for l in db['levantamentos'] if l.get('cnpj') != cnpj]

    db['levantamentos'].append({
        'cnpj':        cnpj,
        'cliente':     cliente,
        'total':       total,
        'data':        data_rel,
        'responsavel': responsavel,
        'timestamp':   datetime.now().isoformat()
    })

    save_db(db)

# ──────────────────────────────────────────────────
# HELPERS de mês
# ──────────────────────────────────────────────────
def mes_de(data_str):
    """Retorna string 'MM/YYYY' a partir de 'DD/MM/YYYY'."""
    try:
        d = datetime.strptime(data_str, '%d/%m/%Y')
        return d.strftime('%m/%Y')
    except:
        return 'Desconhecida'

# ──────────────────────────────────────────────────
# ROTAS
# ──────────────────────────────────────────────────
@app.route('/')
def index():
    return app.send_static_file('index.html')


@app.route('/processar', methods=['POST'])
def processar():
    if 'pdf' not in request.files:
        return jsonify({'erro': 'Nenhum arquivo enviado'}), 400

    pdf_file = request.files['pdf']
    if not pdf_file.filename.lower().endswith('.pdf'):
        return jsonify({'erro': 'Envie um arquivo PDF'}), 400

    responsavel = request.form.get('responsavel', '').strip()
    if not responsavel:
        return jsonify({'erro': 'Selecione o responsável pelo levantamento.'}), 400

    try:
        pdf_bytes = pdf_file.read()
        dados = parse_pdf(pdf_bytes)

        tem_pendencia = dados['rows'] or dados.get('pendencias')
        if not tem_pendencia:
            return jsonify({'erro': 'Nenhuma pendência encontrada no PDF.'}), 422

        # Injeta responsável nos dados para o docx
        dados['responsavel'] = responsavel

        caminho = gerar(dados, TMP_OUT, TEMPLATE_DIR)

        # Salva no banco local
        salvar_levantamento(dados, responsavel)

        nome_cliente = dados['cliente'].replace(' ', '_')[:40]
        nome_arquivo = f'Informativo_Fiscal_{nome_cliente}.docx'

        return send_file(
            caminho,
            as_attachment=True,
            download_name=nome_arquivo,
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )

    except Exception as e:
        traceback.print_exc()
        return jsonify({'erro': str(e)}), 500


@app.route('/preview', methods=['POST'])
def preview():
    if 'pdf' not in request.files:
        return jsonify({'erro': 'Nenhum arquivo enviado'}), 400
    try:
        pdf_bytes = request.files['pdf'].read()
        dados = parse_pdf(pdf_bytes)

        rows_json = [
            {
                'debito':       r[0],
                'periodo':      r[1],
                'vencimento':   r[2],
                'vl_original':  round(float(r[3]), 2),
                'vl_atualizado':round(float(r[4]), 2),
            }
            for r in dados['rows']
        ]

        return jsonify({
            'cliente':    dados['cliente'],
            'cnpj':       dados['cnpj'],
            'data':       dados['data_analise'],
            'cpen':       dados['cpen_validade'],
            'rows':       rows_json,
            'total':      round(dados['total'], 2),
            'pendencias': dados.get('pendencias', {}),
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'erro': str(e)}), 500


@app.route('/stats', methods=['GET'])
def stats():
    """Retorna dados consolidados para o dashboard."""
    try:
        db = load_db()
        levs = db.get('levantamentos', [])

        # Total geral
        total_geral = sum(l.get('total', 0) for l in levs)

        # Ranking empresas (já está deduplicado por CNPJ no save)
        ranking_emp = sorted(levs, key=lambda l: l.get('total', 0), reverse=True)
        ranking_empresas = [
            {
                'cnpj':       l.get('cnpj', ''),
                'cliente':    l.get('cliente', ''),
                'total':      round(l.get('total', 0), 2),
                'ultima_data':l.get('data', ''),
                'responsavel':l.get('responsavel', ''),
            }
            for l in ranking_emp
        ]

        # Ranking colaboradores
        colab = {}
        for l in levs:
            r = l.get('responsavel', 'Desconhecido')
            if r not in colab:
                colab[r] = {'total': 0.0, 'count': 0}
            colab[r]['total'] += l.get('total', 0)
            colab[r]['count'] += 1
        ranking_colab = sorted(
            [{'responsavel': k, 'total': round(v['total'],2), 'count': v['count']} for k,v in colab.items()],
            key=lambda x: x['total'], reverse=True
        )

        # Timeline mensal
        meses = {}
        for l in levs:
            m = mes_de(l.get('data', ''))
            meses[m] = meses.get(m, 0) + l.get('total', 0)
        # Ordena por data real (MM/YYYY -> chave sortável YYYY-MM)
        def sort_key(k):
            try:
                parts = k.split('/')
                return f"{parts[1]}-{parts[0]}"
            except:
                return k
        timeline = [
            {'mes': k, 'total': round(v, 2)}
            for k, v in sorted(meses.items(), key=lambda x: sort_key(x[0]))
        ]

        return jsonify({
            'total_geral':          round(total_geral, 2),
            'total_empresas':       len(set(l.get('cnpj','') for l in levs)),
            'total_levantamentos':  len(levs),
            'ranking_empresas':     ranking_empresas,
            'ranking_colaboradores':ranking_colab,
            'timeline_mensal':      timeline,
        })
    except Exception as e:
        traceback.print_exc()
        return jsonify({'erro': str(e)}), 500


if __name__ == '__main__':
    print('\n' + '='*55)
    print('  🚀  Automação Fiscal ALLDAX rodando!')
    print('  Acesse: http://localhost:5000')
    print('='*55 + '\n')
    app.run(debug=False, port=5000)
