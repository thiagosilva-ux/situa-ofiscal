"""
gerar_docx.py — ALLDAX Automação Fiscal
Gera o .docx a partir dos dados extraídos do PDF da Receita Federal,
incluindo TODAS as seções de pendência (SIEF, SIEFPAR, PGFN, SISPAR, DÍVIDA).

v7 — Tabela de débitos SIEF com 5 colunas (Débito, Período, Vencimento, Valor Original, Valor Atualizado)
     Todas as tabelas genéricas com linha de TOTAL ao final.
"""
import sys, json, shutil, zipfile, re, os
from pathlib import Path
from collections import defaultdict
from datetime import datetime
import xml.etree.ElementTree as ET

NS = {
    'w':  'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'r':  'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'w14':'http://schemas.microsoft.com/office/word/2010/wordml',
}
for pfx, uri in NS.items():
    ET.register_namespace(pfx, uri)

# ═══════════════════════════════════════════════════════════════
# HELPERS XML
# ═══════════════════════════════════════════════════════════════
def esc(t):
    return str(t).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

def fmt_brl(v):
    return f'R$ {float(v):,.2f}'.replace(',','X').replace('.',',').replace('X','.')

def _cell(text, width, align='center', fill=None, bold=False, white=False,
          top='single', left='single', span=None, font='Aptos Narrow'):
    shd   = f'<w:shd w:val="clear" w:color="000000" w:fill="{fill}"/>' if fill else ''
    spanx = f'<w:gridSpan w:val="{span}"/>' if span else ''
    top_v = 'nil' if top  == 'nil' else 'single'
    lft_v = 'nil' if left == 'nil' else 'single'
    clr   = 'FFFFFF' if white else '000000'
    bx    = '<w:b/><w:bCs/>' if bold else ''
    t     = esc(text)
    return f'''<w:tc>
      <w:tcPr>
        <w:tcW w:w="{width}" w:type="dxa"/>
        {spanx}
        <w:tcBorders>
          <w:top    w:val="{top_v}"  w:sz="4" w:space="0" w:color="auto"/>
          <w:left   w:val="{lft_v}"  w:sz="4" w:space="0" w:color="auto"/>
          <w:bottom w:val="single"   w:sz="4" w:space="0" w:color="auto"/>
          <w:right  w:val="single"   w:sz="4" w:space="0" w:color="auto"/>
        </w:tcBorders>
        {shd}
        <w:noWrap/><w:vAlign w:val="center"/><w:hideMark/>
      </w:tcPr>
      <w:p>
        <w:pPr>
          <w:widowControl/><w:autoSpaceDE/><w:autoSpaceDN/>
          <w:jc w:val="{align}"/>
          <w:rPr>
            <w:rFonts w:ascii="{font}" w:eastAsia="Times New Roman" w:hAnsi="{font}" w:cs="Times New Roman"/>
            {bx}<w:color w:val="{clr}"/>
            <w:lang w:val="pt-BR" w:eastAsia="pt-BR"/>
          </w:rPr>
        </w:pPr>
        <w:r>
          <w:rPr>
            <w:rFonts w:ascii="{font}" w:eastAsia="Times New Roman" w:hAnsi="{font}" w:cs="Times New Roman"/>
            {bx}<w:color w:val="{clr}"/>
            <w:lang w:val="pt-BR" w:eastAsia="pt-BR"/>
          </w:rPr>
          <w:t xml:space="preserve">{t}</w:t>
        </w:r>
      </w:p>
    </w:tc>'''

def _row(cells, height=290):
    return f'''<w:tr>
      <w:trPr><w:trHeight w:val="{height}"/><w:jc w:val="center"/></w:trPr>
      {''.join(cells)}
    </w:tr>'''

def _paragraph(text, bold=False, color=None, align='left', font='Cambria', size=None):
    """Parágrafo simples estilo Cambria (igual ao resto do documento)."""
    bx  = '<w:b/><w:bCs/>' if bold else ''
    clr = f'<w:color w:val="{color}"/>' if color else ''
    sz  = f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/>' if size else ''
    t   = esc(text)
    return f'''<w:p>
      <w:pPr>
        <w:pStyle w:val="PargrafodaLista"/>
        <w:jc w:val="{align}"/>
        <w:rPr>
          <w:rFonts w:ascii="{font}" w:hAnsi="{font}"/>
          {bx}{clr}{sz}
        </w:rPr>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:rFonts w:ascii="{font}" w:hAnsi="{font}"/>
          {bx}{clr}{sz}
        </w:rPr>
        <w:t xml:space="preserve">{t}</w:t>
      </w:r>
    </w:p>'''

def _blank():
    return '''<w:p>
      <w:pPr><w:pStyle w:val="PargrafodaLista"/>
        <w:rPr><w:rFonts w:ascii="Cambria" w:hAnsi="Cambria"/></w:rPr>
      </w:pPr>
    </w:p>'''

# ═══════════════════════════════════════════════════════════════
# TABELA PRINCIPAL (débitos SIEF) — 5 colunas
# DÉBITO | PERÍODO | VENCIMENTO | VALOR ORIGINAL | VALOR ATUALIZADO
# ═══════════════════════════════════════════════════════════════
# Larguras das 5 colunas (soma = 9638 para ocupar largura total A4)
C1 = 2200   # DÉBITO
C2 = 900    # PERÍODO
C3 = 1100   # VENCIMENTO
C4 = 1400   # VALOR ORIGINAL
C5 = 1400   # VALOR ATUALIZADO
TABLE_W = C1 + C2 + C3 + C4 + C5  # 7000 dxa

def _tabela_debitos(rows_data, total):
    """
    rows_data: lista de [debito, periodo, vencimento, vl_original, vl_atualizado]
    total: soma dos valores atualizados
    """
    # Cabeçalho
    rows_xml = [_row([
        _cell('DÉBITO',          C1, fill='002060', bold=True, white=True),
        _cell('PERÍODO',         C2, fill='002060', bold=True, white=True, left='nil'),
        _cell('VENCIMENTO',      C3, fill='002060', bold=True, white=True, left='nil'),
        _cell('VALOR ORIGINAL',  C4, fill='002060', bold=True, white=True, left='nil'),
        _cell('VALOR ATUALIZADO',C5, fill='002060', bold=True, white=True, left='nil'),
    ])]

    # Linhas de dados
    for row in rows_data:
        debito, periodo, vencimento, vl_original, vl_atualizado = row
        rows_xml.append(_row([
            _cell(debito,               C1, top='nil', align='left'),
            _cell(periodo,              C2, top='nil', left='nil'),
            _cell(vencimento,           C3, top='nil', left='nil'),
            _cell(fmt_brl(vl_original), C4, top='nil', left='nil'),
            _cell(fmt_brl(vl_atualizado),C5, top='nil', left='nil'),
        ]))

    # Linha de total: "TOTAL" span nas 4 primeiras colunas, valor na última
    total_orig = sum(float(r[3]) for r in rows_data)
    rows_xml.append(_row([
        _cell('TOTAL',            C1+C2+C3+C4, span=4, top='single', bold=True),
        _cell(fmt_brl(total),     C5, fill='FF0000', bold=True, white=True, top='nil', left='nil'),
    ]))

    return f'''<w:tbl>
      <w:tblPr>
        <w:tblW w:w="{TABLE_W}" w:type="dxa"/>
        <w:jc w:val="center"/>
        <w:tblCellMar>
          <w:left w:w="70" w:type="dxa"/>
          <w:right w:w="70" w:type="dxa"/>
        </w:tblCellMar>
        <w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0"
          w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/>
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="{C1}"/>
        <w:gridCol w:w="{C2}"/>
        <w:gridCol w:w="{C3}"/>
        <w:gridCol w:w="{C4}"/>
        <w:gridCol w:w="{C5}"/>
      </w:tblGrid>
      {''.join(rows_xml)}
    </w:tbl>'''

# ═══════════════════════════════════════════════════════════════
# TABELAS EXTRAS (pendências adicionais) — com TOTAL
# ═══════════════════════════════════════════════════════════════
TW = 7000   # mesma largura da tabela principal

def _tabela_generica(colunas, linhas, col_widths=None, idx_valor=None):
    """
    colunas: lista de strings (cabeçalhos)
    linhas: lista de listas de strings
    col_widths: lista de larguras em dxa (soma deve ser TW). Se None, divide igualmente.
    idx_valor: índice da coluna de valor para somar no TOTAL (None = sem total)
    """
    n = len(colunas)
    if col_widths is None:
        base = TW // n
        col_widths = [base] * (n - 1) + [TW - base * (n - 1)]

    # cabeçalho
    header_cells = []
    for i, (col, w) in enumerate(zip(colunas, col_widths)):
        header_cells.append(
            _cell(col, w, fill='002060', bold=True, white=True,
                  left=('nil' if i > 0 else 'single'))
        )
    rows_xml = [_row(header_cells)]

    # linhas de dados
    for linha in linhas:
        cells = []
        for i, (val, w) in enumerate(zip(linha, col_widths)):
            cells.append(
                _cell(str(val), w, top='nil',
                      left=('nil' if i > 0 else 'single'), align='left')
            )
        rows_xml.append(_row(cells))

    # Linha de TOTAL (se houver coluna de valor)
    if idx_valor is not None and linhas:
        total_val = 0.0
        for linha in linhas:
            try:
                v = linha[idx_valor]
                # Remove R$, pontos de milhar, troca vírgula por ponto
                v_clean = re.sub(r'R\$\s*', '', str(v)).replace('.', '').replace(',', '.')
                total_val += float(v_clean)
            except (ValueError, IndexError):
                pass

        # Célula "TOTAL" abrangendo todas as colunas exceto a última (valor)
        span_w = sum(col_widths[:idx_valor])
        val_w  = col_widths[idx_valor]
        # Se idx_valor == última coluna, span abrange n-1 colunas
        if idx_valor == n - 1:
            total_cells = [
                _cell('TOTAL', span_w, span=idx_valor, top='single', bold=True),
                _cell(fmt_brl(total_val), val_w,
                      fill='FF0000', bold=True, white=True, top='nil', left='nil'),
            ]
        else:
            # Coluna de valor no meio: span até idx_valor, célula de valor, resto vazio
            span_w2 = sum(col_widths[idx_valor+1:])
            total_cells = [
                _cell('TOTAL', span_w, span=idx_valor, top='single', bold=True),
                _cell(fmt_brl(total_val), val_w,
                      fill='FF0000', bold=True, white=True, top='nil', left='nil'),
                _cell('', span_w2, span=n-idx_valor-1, top='nil', left='nil'),
            ]
        rows_xml.append(_row(total_cells))

    cols_xml = ''.join(f'<w:gridCol w:w="{w}"/>' for w in col_widths)
    return f'''<w:tbl>
      <w:tblPr>
        <w:tblW w:w="{TW}" w:type="dxa"/>
        <w:jc w:val="center"/>
        <w:tblCellMar>
          <w:left w:w="70" w:type="dxa"/>
          <w:right w:w="70" w:type="dxa"/>
        </w:tblCellMar>
        <w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0"
          w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/>
      </w:tblPr>
      <w:tblGrid>{cols_xml}</w:tblGrid>
      {''.join(rows_xml)}
    </w:tbl>'''

# ═══════════════════════════════════════════════════════════════
# BUILDER DE TODAS AS SEÇÕES EXTRAS
# ═══════════════════════════════════════════════════════════════
def _build_extra_sections(pendencias):
    parts = []

    # ── 2. Omissão DCTFWeb ───────────────────────────────────────────────
    if pendencias.get('omissao_dctfweb'):
        parts.append(_blank())
        parts.append(_paragraph('OMISSÃO DE DCTFWeb — Receita Federal',
                                bold=True, color='002060'))
        linhas = [[per, 'Omissão de entrega', ''] for per in pendencias['omissao_dctfweb']]
        parts.append(_tabela_generica(['Período', 'Situação', 'Valor'],
                                      linhas, col_widths=[1500, 3000, 2500], idx_valor=2))

    # ── 3. Processos SIEF ────────────────────────────────────────────────
    if pendencias.get('processo_fiscal_sief'):
        parts.append(_blank())
        parts.append(_paragraph('PROCESSOS FISCAIS — Receita Federal (SIEF)',
                                bold=True, color='002060'))
        linhas = [
            [p['processo'], p['situacao'],
             fmt_brl(p['valor']) if p.get('valor') else '']
            for p in pendencias['processo_fiscal_sief']
        ]
        parts.append(_tabela_generica(['Nº Processo', 'Situação', 'Valor'],
                                      linhas, col_widths=[2800, 1700, 2500], idx_valor=2))

    # ── 4. Parcelamentos SIEFPAR ─────────────────────────────────────────
    if pendencias.get('parcelamento_siefpar'):
        parts.append(_blank())
        parts.append(_paragraph('PARCELAMENTOS EM ATRASO — Receita Federal (SIEFPAR)',
                                bold=True, color='002060'))
        linhas = [
            [p['numero'], str(p['parcelas_atraso']), fmt_brl(p['valor_atraso'])]
            for p in pendencias['parcelamento_siefpar']
        ]
        parts.append(_tabela_generica(
            ['Nº Parcelamento', 'Parcelas em Atraso', 'Valor em Atraso'],
            linhas, col_widths=[2800, 1700, 2500], idx_valor=2))

    # ── 5. Inscrições PGFN SIDA ──────────────────────────────────────────
    if pendencias.get('inscricao_sida_pgfn'):
        parts.append(_blank())
        parts.append(_paragraph('INSCRIÇÕES — PGFN (SIDA)',
                                bold=True, color='002060'))
        linhas = [
            [i['inscricao'], i['receita'], i['situacao'],
             fmt_brl(i['valor']) if i.get('valor') else '']
            for i in pendencias['inscricao_sida_pgfn']
        ]
        parts.append(_tabela_generica(
            ['Inscrição', 'Receita', 'Situação', 'Valor'],
            linhas, col_widths=[1600, 1500, 1400, 2500], idx_valor=3))

    # ── 6. Parcelamentos PGFN SISPAR ─────────────────────────────────────
    if pendencias.get('parcelamento_sispar_pgfn'):
        parts.append(_blank())
        parts.append(_paragraph('PARCELAMENTOS — PGFN (SISPAR)',
                                bold=True, color='002060'))
        linhas = [
            [c['conta'], c['descricao'], c['modalidade'],
             fmt_brl(c['valor']) if c.get('valor') else '']
            for c in pendencias['parcelamento_sispar_pgfn']
        ]
        parts.append(_tabela_generica(
            ['Conta', 'Descrição', 'Modalidade', 'Valor'],
            linhas, col_widths=[1200, 1500, 1800, 2500], idx_valor=3))

    # ── 7. Inscrições Sistema DÍVIDA ─────────────────────────────────────
    if pendencias.get('inscricao_sistema_divida'):
        parts.append(_blank())
        parts.append(_paragraph('INSCRIÇÕES — Sistema DÍVIDA Ativa',
                                bold=True, color='002060'))
        linhas = [
            [d['inscricao'], d['situacao'],
             fmt_brl(d['valor']) if d.get('valor') else '']
            for d in pendencias['inscricao_sistema_divida']
        ]
        parts.append(_tabela_generica(
            ['Inscrição', 'Situação', 'Valor'],
            linhas, col_widths=[2000, 2500, 2500], idx_valor=2))

    return '\n'.join(parts)

# ═══════════════════════════════════════════════════════════════
# PATCH PRINCIPAL DO XML
# ═══════════════════════════════════════════════════════════════
def patch_document_xml(xml_str, dados):
    cliente      = dados['cliente']
    cnpj         = dados['cnpj']
    data_analise = dados['data_analise']
    cpen_val     = dados['cpen_validade']
    rows         = dados['rows']
    total        = dados['total']
    pendencias   = dados.get('pendencias', {})

    # 1. Cliente
    xml_str = xml_str.replace('nome da empresa', cliente)
    # 2. CNPJ
    xml_str = xml_str.replace('> cnpj<', f'> {cnpj}<')
    xml_str = xml_str.replace('>cnpj<',  f'>{cnpj}<')
    xml_str = re.sub(r'(?<=preserve\">)\s*cnpj(?=<)', f' {cnpj}', xml_str)
    # 3. Data da Análise
    xml_str = xml_str.replace('xx/xx/20xx', data_analise)
    # 4. CPEN validade
    xml_str = xml_str.replace('>VENCIDA<', f'>{cpen_val}<')
    # 5. Data da assinatura
    xml_str = xml_str.replace('09 de abril de 2026',
                               dados.get('data_assinatura', '04 de junho de 2026'))

    # 6. Substituir tabela principal
    tabela_nova = _tabela_debitos(rows, total)
    xml_str = re.sub(r'<w:tbl>.*?</w:tbl>', tabela_nova, xml_str, flags=re.DOTALL)

    # 7. Injetar seções extras APÓS a tabela, ANTES da assinatura
    extra_xml = _build_extra_sections(pendencias)
    if extra_xml:
        brasilia_pos = xml_str.find('Brasília-DF')
        p_start = xml_str.rfind('<w:p ', 0, brasilia_pos)
        xml_str = xml_str[:p_start] + extra_xml + '\n    ' + xml_str[p_start:]

    return xml_str

# ═══════════════════════════════════════════════════════════════
# PIPELINE PRINCIPAL
# ═══════════════════════════════════════════════════════════════
def gerar(dados: dict, output_path: str, template_dir: str):
    work = Path('/tmp/docx_work')
    if work.exists():
        shutil.rmtree(work)
    shutil.copytree(template_dir, work)

    doc_xml_path = work / 'word' / 'document.xml'
    xml_str = doc_xml_path.read_text(encoding='utf-8')
    xml_str = patch_document_xml(xml_str, dados)
    doc_xml_path.write_text(xml_str, encoding='utf-8')

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zf:
        for f in sorted(work.rglob('*')):
            if f.is_file():
                zf.write(f, f.relative_to(work))
    return str(out)

# ═══════════════════════════════════════════════════════════════
# EXTRAÇÃO PDF
# ═══════════════════════════════════════════════════════════════
def _extrair_texto_pdf(pdf_path: str) -> str:
    try:
        import pdfplumber
        with pdfplumber.open(pdf_path) as doc:
            return '\n'.join(page.extract_text() or '' for page in doc.pages)
    except ImportError:
        pass
    try:
        from pdfminer.high_level import extract_text as pdfminer_extract
        return pdfminer_extract(pdf_path)
    except ImportError:
        pass
    try:
        from pypdf import PdfReader
        reader = PdfReader(pdf_path)
        return '\n'.join(p.extract_text() or '' for p in reader.pages)
    except ImportError:
        pass
    raise RuntimeError("Instale pdfplumber, pdfminer.six ou pypdf")

def parse_pdf(pdf_bytes: bytes) -> dict:
    import tempfile
    with tempfile.NamedTemporaryFile(suffix='.pdf', delete=False) as tmp:
        tmp.write(pdf_bytes)
        tmp_path = tmp.name
    try:
        full_text = _extrair_texto_pdf(tmp_path)
        # Normaliza quebras causadas pelo pdfplumber em períodos trimestrais.
        # O pdfplumber extrai: "... 1º  30/04/2026 ... DEVEDOR\nTRIM/2026\n..."
        # Precisamos mover o TRIM/YYYY para junto do 1º antes dos números.
        # Passo 1: remove linha solta "TRIM/YYYY" e guarda o valor
        # Passo 2: substitui "1º" seguido de data por "1º TRIM/YYYY" + data
        def _fix_trim(text):
            # Encontra padrões "NUMERO° ... DEVEDOR\nTRIM/YYYY" e reestrutura
            # para "NUMERO° TRIM/YYYY ... DEVEDOR"
            import re as _re
            # Captura: código - receita  Nº°  DT_VCTO  nums  DEVEDOR\nTRIM/YYYY
            pat = _re.compile(
                r'(\d{4}-\d{2}\s*-\s*[^\n]+?)\s+(\d[°º])\s+(\d{2}/\d{2}/\d{4})'
                r'((?:\s+[\d.,]+)+)\s+DEVEDOR\s*\nTRIM/(\d{4})'
            )
            return pat.sub(lambda m: f'{m.group(1)} {m.group(2)} TRIM/{m.group(5)} {m.group(3)}{m.group(4)} DEVEDOR', text)
        full_text = _fix_trim(full_text)
    finally:
        try: os.unlink(tmp_path)
        except: pass

    # ── CNPJ completo ────────────────────────────────────────────────────
    m_cnpj = re.search(r'CNPJ:\s*(\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2})', full_text)
    if not m_cnpj:
        m_cnpj = re.search(r'CNPJ:\s*([\d./\-]+)', full_text)
    cnpj = m_cnpj.group(1).strip() if m_cnpj else ''

    m_cliente = re.search(r'CNPJ:\s*[\d./\-]+\s*-\s*(.+)', full_text)
    cliente = m_cliente.group(1).strip().split('\n')[0].strip() if m_cliente else ''

    m_data = re.search(r'(\d{2}/\d{2}/\d{4})\s+\d{2}:\d{2}:\d{2}', full_text)
    data_rel = m_data.group(1) if m_data else datetime.today().strftime('%d/%m/%Y')

    m_cpen = re.search(r'Data de Validade:\s*(\d{2}/\d{2}/\d{4})', full_text)
    cpen_val = m_cpen.group(1) if m_cpen else 'VENCIDA'

    pendencias = {}

    # ── 1. Débitos SIEF — captura 5 campos: receita, período, vencimento, vl_original, vl_atualizado ──
    # Formato da linha no PDF:
    #   CÓDIGO - RECEITA   PA/Exerc.   Dt.Vcto   Vl.Original   Sdo.Devedor   Multa   Juros   Sdo.Dev.Cons.   DEVEDOR
    # Queremos: receita, período (PA/Exerc.), vencimento (Dt.Vcto), vl_original, vl_atualizado (Sdo.Dev.Cons.)
    pat_debito = re.compile(
        r'(\d{4}-\d{2}\s*-\s*[\w\-./]+(?:\s+[\w\-./]+)*?)'
        r'\s+(\d[°º]\s*TRIM/\d{4}|\d{2}/\d{2}/\d{4}|\d{2}/\d{4}|\d{4})'
        r'\s+(\d{2}/\d{2}/\d{4})'
        r'\s+([\d.]+,\d{2})'
        r'\s+([\d.]+,\d{2})'
        r'\s+([\d.]+,\d{2})'
        r'\s+([\d.]+,\d{2})'
        r'\s+([\d.]+,\d{2})'
        r'\s+DEVEDOR'
    )

    # Simples NAC.: sem código numérico, 7 ou 8 colunas numéricas
    pat_simples = re.compile(
        r'SIMPLES\s+NAC\.?\s+'
        r'(\d{2}/\d{4}|\d{1}[°o]\s*TRIM/\d{4})'
        r'\s+(\d{2}/\d{2}/\d{4})'
        r'\s+([\d.]+,\d{2})'
        r'\s+([\d.]+,\d{2})'
        r'\s+([\d.]+,\d{2})'
        r'(?:\s+([\d.]+,\d{2}))?'
        r'\s+([\d.]+,\d{2})'
        r'\s+DEVEDOR'
    )

    def _parse_brl(s):
        return float(s.replace('.', '').replace(',', '.'))

    raw_rows = []

    # Débitos SIEF normais (com código numérico)
    for m in pat_debito.finditer(full_text):
        receita = re.sub(r'^\d{4}-\d{2}\s*-\s*', '', m.group(1)).strip().rstrip('.')
        if re.search(r'CP[-\s]', receita, re.IGNORECASE):
            receita = 'INSS'

        periodo = m.group(2).strip()
        vencimento = m.group(3).strip()

        if re.fullmatch(r'\d{4}', periodo):
            periodo = f'13º/{periodo}'
        elif re.fullmatch(r'\d{2}/\d{2}/\d{4}', periodo):
            dd, mm, aaaa = periodo.split('/')
            periodo = f'{mm}/{aaaa}'

        vl_original   = _parse_brl(m.group(4))
        vl_atualizado = _parse_brl(m.group(8))
        raw_rows.append((receita, periodo, vencimento, vl_original, vl_atualizado))

    # Débitos Simples Nacional
    for m in pat_simples.finditer(full_text):
        periodo    = m.group(1).strip()
        vencimento = m.group(2).strip()
        vl_original   = _parse_brl(m.group(3))
        vl_atualizado = _parse_brl(m.group(7))
        raw_rows.append(('SIMPLES NAC.', periodo, vencimento, vl_original, vl_atualizado))

    def sort_key(p):
        if re.fullmatch(r'\d{2}/\d{4}', p):
            mm, aa = p.split('/')
            return (int(aa), int(mm))
        elif p.startswith('13º/'):
            aa = p.split('/')[1]
            return (int(aa), 13)
        else:
            return (9999, 99)

    # INSS: agrupa por período (soma valores), mantém 1º vencimento encontrado
    inss_orig   = defaultdict(float)
    inss_atu    = defaultdict(float)
    inss_vcto   = {}
    outros = []

    for rec, per, vcto, orig, atu in raw_rows:
        if rec == 'INSS':
            inss_orig[per] += orig
            inss_atu[per]  += atu
            if per not in inss_vcto:
                inss_vcto[per] = vcto
        else:
            outros.append([rec, per, vcto, orig, atu])

    rows_debito = outros[:]
    for per in sorted(inss_orig, key=sort_key):
        rows_debito.append(['INSS', per, inss_vcto[per], inss_orig[per], inss_atu[per]])

    total = sum(r[4] for r in rows_debito)
    if rows_debito:
        pendencias['debito_sief'] = {'rows': rows_debito, 'total': total}

    # ── 2. Omissão DCTFWeb ───────────────────────────────────────────────
    m_dctf = re.search(
        r'Pendência - Omissão de DCTFWeb\*.*?\(Período de Apuração\)(.*?)\*Ausência',
        full_text, re.DOTALL)
    if m_dctf:
        dctf_list = []
        for ano, meses_str in re.findall(r'(\d{4})\s*-\s*((?:[A-Z]{3}\s*)+)', m_dctf.group(1)):
            for mes in meses_str.strip().split():
                dctf_list.append(f'{mes}/{ano}')
        if dctf_list:
            pendencias['omissao_dctfweb'] = dctf_list

    # ── 3. Processos SIEF ────────────────────────────────────────────────
    m_proc = re.search(
        r'Pendência - Processo Fiscal \(SIEF\).*?CNPJ:.*?\n(.*?)'
        r'(?:Processo Fiscal com Exigibilidade|Pendência|Diagnóstico|$)',
        full_text, re.DOTALL)
    if m_proc:
        processos = []
        bloco = m_proc.group(1)
        # Formato do processo: 12420.002.714/2019-17  (5 dígitos . 3 . 3 / 4 - 2)
        for m in re.finditer(
            r'(\d{5}\.\d{3}\.\d{3}/\d{4}-\d{2})\s+(DEVEDOR|CREDOR|EM\s+ANDAMENTO|SUSPENSO)',
            bloco, re.IGNORECASE):
            situacao = m.group(2).strip().upper()
            # Tenta capturar localização na mesma linha
            linha_rest = bloco[m.end():m.end()+120]
            loc_m = re.search(r'([A-Z][A-Z ]{5,})', linha_rest)
            localizacao = loc_m.group(1).strip() if loc_m else ''
            valor_m = re.search(r'[\d.]+,\d{2}', linha_rest)
            valor = float(valor_m.group().replace('.','').replace(',','.')) if valor_m else 0.0
            processos.append({
                'processo':     m.group(1).strip(),
                'situacao':     situacao,
                'localizacao':  localizacao,
                'valor':        valor
            })
        if processos:
            pendencias['processo_fiscal_sief'] = processos

    # ── 4. Parcelamentos SIEFPAR ─────────────────────────────────────────
    m_siefpar = re.search(
        r'Pendência\s*[–\-]\s*Parcelamento \(SIEFPAR\).*?CNPJ:.*?\n(.*?)'
        r'(?:Parcelamento com Exigibilidade|Débito com Exigibilidade|Diagnóstico|$)',
        full_text, re.DOTALL)
    if m_siefpar:
        parcs = []
        for m in re.finditer(
            r'Parcelamento:\s*([\w.\-]+)\s+Parcelas em Atraso:\s*(\d+)\s+Valor em Atraso:\s*([\d.,]+)',
            m_siefpar.group(1)):
            parcs.append({
                'numero':          m.group(1).strip(),
                'parcelas_atraso': int(m.group(2)),
                'valor_atraso':    float(m.group(3).replace('.', '').replace(',', '.'))
            })
        if parcs:
            pendencias['parcelamento_siefpar'] = parcs

    # ── 5. PGFN SIDA ─────────────────────────────────────────────────────
    m_sida = re.search(
        r'Pendência - Inscrição \(SIDA\).*?CNPJ:.*?\nInscrição\s+Receita.*?\n(.*?)'
        r'(?:Inscrição com Exigibilidade|Pendência|Diagnóstico|$)',
        full_text, re.DOTALL)
    if m_sida:
        inscricoes = []
        for m in re.finditer(
            r'([\d.]+\-\d+)\s+([\w\-./]+(?:\s+[\w\-./]+)*?)\s+\d{2}/\d{2}/\d{4}.*?\nSituação:\s*(.+)',
            m_sida.group(1)):
            valor_m = re.search(r'([\d.]+,\d{2})', full_text[m.end():m.end()+80])
            valor = float(valor_m.group(1).replace('.','').replace(',','.')) if valor_m else 0.0
            inscricoes.append({
                'inscricao': m.group(1).strip(),
                'receita':   m.group(2).strip(),
                'situacao':  m.group(3).strip(),
                'valor':     valor
            })
        if inscricoes:
            pendencias['inscricao_sida_pgfn'] = inscricoes

    # ── 6. PGFN SISPAR ───────────────────────────────────────────────────
    m_sispar = re.search(
        r'Pendência - Parcelamento \(SISPAR\).*?CNPJ:.*?\nConta\n(.*?)'
        r'(?:Inscrição|Pendência|Final do Relatório|$)',
        full_text, re.DOTALL)
    if m_sispar:
        contas = []
        for m in re.finditer(
            r'(\d{9})\s+(.+?)\nModalidade:\s*(.+?)(?=\n\d{9}|\Z)',
            m_sispar.group(1), re.DOTALL):
            valor_m = re.search(r'([\d.]+,\d{2})', m.group(3))
            valor = float(valor_m.group(1).replace('.','').replace(',','.')) if valor_m else 0.0
            contas.append({
                'conta':      m.group(1).strip(),
                'descricao':  m.group(2).strip(),
                'modalidade': m.group(3).strip(),
                'valor':      valor
            })
        if contas:
            pendencias['parcelamento_sispar_pgfn'] = contas

    # ── 7. Sistema DÍVIDA ────────────────────────────────────────────────
    m_divida = re.search(
        r'Pendência - Inscrição \(Sistema DIVIDA\).*?CNPJ:.*?\n(.*?)'
        r'(?:Final do Relatório|$)',
        full_text, re.DOTALL)
    if m_divida:
        dividas = []
        for m in re.finditer(r'Inscrição:\s*([\d.\-]+)\s+Situação:\s*(.+)', m_divida.group(1)):
            valor_m = re.search(r'([\d.]+,\d{2})', full_text[m.end():m.end()+80])
            valor = float(valor_m.group(1).replace('.','').replace(',','.')) if valor_m else 0.0
            dividas.append({'inscricao': m.group(1).strip(), 'situacao': m.group(2).strip(), 'valor': valor})
        if dividas:
            pendencias['inscricao_sistema_divida'] = dividas

    # data por extenso
    meses_ext = ['janeiro','fevereiro','março','abril','maio','junho',
                 'julho','agosto','setembro','outubro','novembro','dezembro']
    try:
        d = datetime.strptime(data_rel, '%d/%m/%Y')
        data_ext = f'{d.day:02d} de {meses_ext[d.month-1]} de {d.year}'
    except:
        data_ext = data_rel

    return {
        'cliente':         cliente,
        'cnpj':            cnpj,
        'data_analise':    data_rel,
        'cpen_validade':   cpen_val,
        'data_assinatura': data_ext,
        'rows':            rows_debito,
        'total':           total,
        'pendencias':      pendencias,
    }


if __name__ == '__main__':
    pdf_path = sys.argv[1] if len(sys.argv) > 1 else '/mnt/user-data/uploads/relatório_fiscal.pdf'
    with open(pdf_path, 'rb') as f:
        dados = parse_pdf(f.read())
    print(json.dumps(dados, ensure_ascii=False, indent=2))
    template_dir = str(Path(__file__).parent / 'template_base')\

    if Path(template_dir).exists():
        out = gerar(dados, '/tmp/teste_template.docx', template_dir)
        print(f'\nDocumento gerado: {out}')
